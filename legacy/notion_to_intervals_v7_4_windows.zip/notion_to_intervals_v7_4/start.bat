@echo off
python "%~dp0notion_to_intervals_v7.py"
pause
