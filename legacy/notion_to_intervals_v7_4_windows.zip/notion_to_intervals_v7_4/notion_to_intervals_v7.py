
import base64
import os
import json
import re
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

CONFIG_PATH = Path.home() / ".notion_to_intervals_v3.json"
NOTION_VERSION = "2022-06-28"

SPORT_MAP = {
    "Course": "Run",
    "Course à pied": "Run",
    "Running": "Run",
    "Run": "Run",
    "CAP": "Run",
    "Vélo": "Ride",
    "Velo": "Ride",
    "Bike": "Ride",
    "Cyclisme": "Ride",
    "Home trainer": "Ride",
    "HT": "Ride",
    "Natation": "Swim",
    "Swim": "Swim",
    "Piscine": "Swim",
}

DEFAULT_DATABASE_ID = "3879cd904ec380a6bb8dd05772b2a25f"

PROPERTY_DATE = "Date planifiée/réalisée"
PROPERTY_SPORT = "Sport"
PROPERTY_NAME = "Séance"
PROPERTY_DETAILS = "Détails séance"
PROPERTY_SYNC = "Sync Intervals"
PROPERTY_STATUS = "Status"
PROPERTY_ID = "ID Séance"

STATUS_SYNC = "Sync"

SECTION_ALIASES = {
    "échauffement": "Warmup",
    "echauffement": "Warmup",
    "warmup": "Warmup",
    "corps de séance": "Main Set",
    "corps de seance": "Main Set",
    "main set": "Main Set",
    "séance": "Main Set",
    "seance": "Main Set",
    "retour au calme": "Cooldown",
    "cooldown": "Cooldown",
    "option vélo": "Main Set",
    "option velo": "Main Set",
    "vélo": "Main Set",
    "velo": "Main Set",
    "séance simple": "Main Set",
    "seance simple": "Main Set",
    "récupération active vélo": "Main Set",
    "recuperation active velo": "Main Set",
    "retour au calme vélo": "Cooldown",
    "retour au calme velo": "Cooldown",
    "échauffement avant course": "Warmup",
    "echauffement avant course": "Warmup",
    "course": "Main Set",
    "récupération": "Recovery",
    "recuperation": "Recovery",
}

def load_config():
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_config(database_id):
    CONFIG_PATH.write_text(json.dumps({"database_id": database_id}, indent=2), encoding="utf-8")

def http_json(method, url, headers=None, payload=None, timeout=45):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = Request(url, data=data, method=method, headers=headers or {})
    try:
        with urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", errors="replace")
            if not body:
                return resp.status, None
            return resp.status, json.loads(body)
    except HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code}\n{body}") from e
    except URLError as e:
        raise RuntimeError(f"Erreur réseau : {e}") from e

def notion_headers(token):
    return {
        "Authorization": f"Bearer {token}",
        "Notion-Version": NOTION_VERSION,
        "Content-Type": "application/json",
    }

def intervals_headers(api_key):
    auth = base64.b64encode(f"API_KEY:{api_key}".encode("utf-8")).decode("ascii")
    return {
        "Authorization": f"Basic {auth}",
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 NotionToIntervalsV3.1/1.0",
    }

def get_plain_text(prop):
    if not prop:
        return ""
    t = prop.get("type")
    if t == "title":
        return "".join(x.get("plain_text", "") for x in prop.get("title", []))
    if t == "rich_text":
        return "".join(x.get("plain_text", "") for x in prop.get("rich_text", []))
    if t == "select":
        sel = prop.get("select")
        return sel.get("name", "") if sel else ""
    if t == "status":
        st = prop.get("status")
        return st.get("name", "") if st else ""
    if t == "date":
        d = prop.get("date")
        return d.get("start", "") if d else ""
    if t == "checkbox":
        return "true" if prop.get("checkbox") else "false"
    if t == "number":
        v = prop.get("number")
        return "" if v is None else str(v)
    if t == "unique_id":
        uid = prop.get("unique_id") or {}
        prefix = uid.get("prefix") or ""
        number = uid.get("number")
        return f"{prefix}-{number}" if prefix and number is not None else (str(number) if number is not None else "")
    if t == "formula":
        formula = prop.get("formula", {})
        ft = formula.get("type")
        value = formula.get(ft, "")
        if ft == "string":
            return value or ""
        if ft == "number":
            return "" if value is None else str(value)
        if ft == "date":
            return (value or {}).get("start", "") if value else ""
        if ft == "boolean":
            return "true" if value else "false"
        return str(value or "")
    return ""

def get_date(prop):
    if not prop or prop.get("type") != "date" or not prop.get("date"):
        return ""
    return prop["date"].get("start", "")[:10]

def get_prop(props, *names):
    for name in names:
        if name in props:
            return props.get(name)
    return None

def query_notion_pages(token, database_id):
    url = f"https://api.notion.com/v1/databases/{database_id}/query"
    payload = {
        "filter": {
            "and": [
                {"property": PROPERTY_SYNC, "checkbox": {"equals": True}},
                {"property": PROPERTY_STATUS, "status": {"equals": "To do"}},
            ]
        },
        "page_size": 50
    }
    pages = []
    while True:
        _, res = http_json("POST", url, headers=notion_headers(token), payload=payload)
        pages.extend(res.get("results", []))
        if not res.get("has_more"):
            break
        payload["start_cursor"] = res.get("next_cursor")
    return pages

def update_notion_status(token, page_id, status_name):
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"properties": {PROPERTY_STATUS: {"status": {"name": status_name}}}}
    return http_json("PATCH", url, headers=notion_headers(token), payload=payload)

def normalize_text(s):
    s = s.replace("’", "'").replace("′", "'").replace("“", '"').replace("”", '"')
    s = s.replace("×", "x").replace("–", "-").replace("—", "-")
    return s

def normalize_pace(pace):
    pace = pace.strip().replace("/km", "")

    # Format court : 5' signifie 5:00/km.
    m = re.fullmatch(r"(\d+)['’]", pace)
    if m:
        return f"{int(m.group(1))}:00"

    pace = pace.replace("'", ":").replace("’", ":")
    m = re.fullmatch(r"(\d+):(\d{1,2})", pace)
    if not m:
        return pace
    return f"{int(m.group(1))}:{int(m.group(2)):02d}"

def normalize_duration(value, unit):
    value = value.strip()
    unit = unit.lower()
    if unit in ["'", "min", "m"]:
        return f"{value}m"
    if unit in ['"', "s"]:
        return f"{value}s"
    if unit == "h":
        return f"{value}h"
    return f"{value}{unit}"


def normalize_duration_expression(raw):
    """
    Convertit les durées humaines simples en syntaxe Intervals.
    Exemples :
    - 1h -> 1h
    - 1h05 -> 65m
    - 1h05min -> 65m
    - 45min -> 45m
    - 50' -> 50m
    """
    value = normalize_text(raw).strip().lower().replace(" ", "")

    m = re.fullmatch(r"(?P<h>\d+)h(?P<m>\d{1,2})?(?:min|m)?", value)
    if m:
        hours = int(m.group("h"))
        minutes = int(m.group("m") or 0)
        if minutes:
            return f"{hours * 60 + minutes}m"
        return f"{hours}h"

    m = re.fullmatch(r"(?P<n>\d+)(?P<u>'|min|m|s|\")", value)
    if m:
        return normalize_duration(m.group("n"), m.group("u"))

    raise ValueError(f"Durée non reconnue : {raw}")

def detect_section(line):
    raw = line.strip().lstrip("#").strip().lower()
    return SECTION_ALIASES.get(raw)


def split_sections(details):
    """Découpe les vraies sections d'entraînement et exclut les métadonnées de tête."""
    details = normalize_text(details)
    sections = []
    current_name = None
    current_lines = []
    started_training = False
    skip = False

    excluded_headings = {
        "volume", "main set", "mainset", "résumé", "resume",
        "synthèse", "synthese", "objectif"
    }

    def flush():
        nonlocal current_lines
        if current_name and current_lines and not skip:
            sections.append((current_name, current_lines))
        current_lines = []

    for raw in details.splitlines():
        line = raw.strip()
        if not line:
            continue

        if line.startswith("#"):
            heading = line.lstrip("#").strip().lower()
            section = detect_section(line)

            if section:
                flush()
                current_name = section
                current_lines = []
                skip = False
                started_training = True
                continue

            if not started_training and heading in excluded_headings:
                flush()
                current_name = None
                skip = True
                continue

            if not started_training:
                flush()
                current_name = None
                skip = True
            continue

        if skip and not started_training:
            continue

        line = re.sub(r"^[•\-]\s*", "", line).strip()
        if not line:
            continue

        # Exclut les synthèses de volume placées en tête.
        if re.match(r"^\d+\s*(?:'|min|h)\s*/", line, flags=re.I):
            continue
        if re.search(r"\b\d+\s*(?:à|-)\s*\d+\s*km\b", line, flags=re.I) and "/" in line:
            continue

        if current_name is None:
            current_name = "Main Set"
            started_training = True
            skip = False

        current_lines.append(line)

    flush()
    return sections

def compile_running_line(line):
    line = normalize_text(line).strip()

    duration_expr = r"(?:\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))"

    # 0) Séance simple : durée + zone d'allure, ex. 1h Z2 ou 45min Z1-Z2
    m = re.fullmatch(
        rf"(?P<dur>{duration_expr})\s+(?P<zone>Z[1-7](?:\s*-\s*Z[1-7])?)\s*(?:Pace|allure)?",
        line,
        flags=re.I,
    )
    if m:
        zone = re.sub(r"\s+", "", m.group("zone").upper())
        return {"steps": [f"- {normalize_duration_expression(m.group('dur'))} {zone} Pace"]}

    # 1) Répétition temps + plage d'allure + récupération
    m = re.search(
        r"(?P<count>\d+)\s*x\s*(?P<dur>\d+)\s*(?P<unit>'|min|m|s|\")"
        r".*?(?:à|a|@)\s*(?P<p1>\d[':]\d{1,2})\s*-\s*(?P<p2>\d[':]\d{1,2})"
        r".*?(?:récupération|recuperation|r=|r)\s*(?P<rec>\d+)\s*(?P<recunit>'|min|m|s|\")",
        line, flags=re.I
    )
    if m:
        return {
            "repeat": int(m.group("count")),
            "steps": [
                f"- {normalize_duration(m.group('dur'), m.group('unit'))} {normalize_pace(m.group('p1'))}-{normalize_pace(m.group('p2'))} Pace",
                f"- {normalize_duration(m.group('rec'), m.group('recunit'))}"
            ]
        }

    # 2) Durée (y compris 1h / 1h05) + plage d'allure
    m = re.search(
        rf"(?P<dur>{duration_expr})"
        r".*?(?:à|a|@)\s*(?P<p1>\d[':]\d{1,2})\s*-\s*(?P<p2>\d[':]\d{1,2})(?:\s*/?\s*km)?",
        line, flags=re.I
    )
    if m:
        return {"steps": [
            f"- {normalize_duration_expression(m.group('dur'))} "
            f"{normalize_pace(m.group('p1'))}-{normalize_pace(m.group('p2'))} Pace"
        ]}

    # 3) Distance + plage d'allure
    m = re.search(
        r"(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>km|m)"
        r".*?(?:à|a|@)\s*(?P<p1>\d[':]\d{1,2})\s*-\s*(?P<p2>\d[':]\d{1,2})",
        line, flags=re.I
    )
    if m:
        dist = m.group("dist").replace(",", ".")
        return {"steps": [
            f"- {dist}{m.group('unit').lower()} "
            f"{normalize_pace(m.group('p1'))}-{normalize_pace(m.group('p2'))} Pace"
        ]}

    # 4) Durée + allure unique
    m = re.search(
        rf"(?P<dur>{duration_expr})"
        r".*?(?:à|a|@)\s*(?P<pace>\d+(?:[':]\d{1,2}|['’]))(?:\s*/?\s*km)?",
        line, flags=re.I
    )
    if m:
        return {"steps": [
            f"- {normalize_duration_expression(m.group('dur'))} {normalize_pace(m.group('pace'))} Pace"
        ]}

    # 5) Distance + allure unique
    m = re.search(
        r"(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>km|m)"
        r".*?(?:à|a|@)\s*(?P<pace>\d+(?:[':]\d{1,2}|['’]))",
        line, flags=re.I
    )
    if m:
        dist = format_distance_for_intervals(m.group("dist"), m.group("unit"))
        return {"steps": [f"- {dist} {normalize_pace(m.group('pace'))} Pace"]}

    # 6) Distance + zone d'allure, ex. 10km Z2
    m = re.fullmatch(
        r"(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>km|m)\s+(?P<zone>Z[1-7](?:\s*-\s*Z[1-7])?)",
        line,
        flags=re.I,
    )
    if m:
        dist = m.group("dist").replace(",", ".")
        zone = re.sub(r"\s+", "", m.group("zone").upper())
        return {"steps": [f"- {dist}{m.group('unit').lower()} {zone} Pace"]}

    # 7) Répétition simple + récupération
    m = re.search(
        r"(?P<count>\d+)\s*x\s*(?P<dur>\d+)\s*(?P<unit>'|min|m|s|\")"
        r".*?(?:récupération|recuperation|r=|r)\s*(?P<rec>\d+)\s*(?P<recunit>'|min|m|s|\")",
        line, flags=re.I
    )
    if m:
        return {
            "repeat": int(m.group("count")),
            "steps": [
                f"- {normalize_duration(m.group('dur'), m.group('unit'))}",
                f"- {normalize_duration(m.group('rec'), m.group('recunit'))}"
            ]
        }

    # 8) Durée variable réelle
    m = re.search(
        r"(?P<d1>\d+)\s+(?:à|a|-)\s+(?P<d2>\d+)\s*(?P<unit>'|min|m)\b",
        line, flags=re.I
    )
    if m:
        return {
            "steps": [f"- {normalize_duration(m.group('d2'), m.group('unit'))}"],
            "warning": f"Durée variable détectée « {m.group('d1')} à {m.group('d2')} » : borne haute utilisée."
        }

    # 9) Durée simple : 1h, 1h05, 45min, 50'
    m = re.fullmatch(rf"(?P<dur>{duration_expr})(?:\s+(?:facile|libre|souple|endurance fondamentale|EF))?", line, flags=re.I)
    if m:
        return {"steps": [f"- {normalize_duration_expression(m.group('dur'))}"]}

    # 10) Distance simple
    m = re.fullmatch(r"(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>km|m)(?:\s+(?:facile|libre|souple))?", line, flags=re.I)
    if m:
        dist = format_distance_for_intervals(m.group("dist"), m.group("unit"))
        return {"steps": [f"- {dist}"]}

    return {"error": f"Ligne running non comprise : {line}"}


def compile_ride_line(line):
    line = normalize_text(line).strip()

    m = re.search(
        r"(?P<count>\d+)\s*x\s*(?P<dur>\d+)\s*(?P<unit>'|min|m|s|\")"
        r".*?@?\s*(?P<power>\d+)\s*w"
        r".*?(?:récupération|recuperation|r=|r)\s*(?P<rec>\d+)\s*(?P<recunit>'|min|m|s|\")",
        line,
        flags=re.I,
    )
    if m:
        return {
            "repeat": int(m.group("count")),
            "steps": [
                f"- {normalize_duration(m.group('dur'), m.group('unit'))} {m.group('power')}w",
                f"- {normalize_duration(m.group('rec'), m.group('recunit'))}"
            ]
        }

    m = re.search(
        r"(?P<dur>\d+)\s*(?P<unit>'|min|m|s|\")"
        r".*?(?P<p1>\d+)\s*-\s*(?P<p2>\d+)\s*w",
        line,
        flags=re.I,
    )
    if m:
        return {
            "steps": [
                f"- {normalize_duration(m.group('dur'), m.group('unit'))} {m.group('p1')}-{m.group('p2')}w"
            ]
        }

    m = re.search(
        r"(?P<dur>\d+)\s*(?P<unit>'|min|m|s|\")"
        r".*?(?P<pct>\d+)\s*%",
        line,
        flags=re.I,
    )
    if m:
        return {
            "steps": [
                f"- {normalize_duration(m.group('dur'), m.group('unit'))} {m.group('pct')}%"
            ]
        }

    m = re.fullmatch(r"(?P<dur>(?:\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\")))(?:\s+(?:Z[1-7]|facile|libre|souple))?", line, flags=re.I)
    if m:
        return {"steps": [f"- {normalize_duration_expression(m.group('dur'))}"]}

    return {"error": f"Ligne vélo non comprise : {line}"}

def compile_swim_line(line):
    line = normalize_text(line).strip()

    m = re.search(
        r"(?P<count>\d+)\s*x\s*(?P<dist>\d+)\s*m"
        r".*?(?:récupération|recuperation|r=|r)\s*(?P<rec>\d+)\s*(?:s|\")",
        line,
        flags=re.I,
    )
    if m:
        return {
            "repeat": int(m.group("count")),
            "steps": [
                f"- {m.group('dist')}m",
                f"- {m.group('rec')}s"
            ]
        }

    m = re.search(r"(?P<dist>\d+)\s*m\b", line, flags=re.I)
    if m:
        return {"steps": [f"- {m.group('dist')}m"]}

    return {"error": f"Ligne natation non comprise : {line}"}

def compile_details(details, intervals_type):
    forced = re.search(r"INTERVALS\s*:\s*(.*)", details, flags=re.I | re.S)
    if forced:
        return forced.group(1).strip(), []

    sections = split_sections(details)
    output = []
    warnings = []

    compiler = compile_running_line
    if intervals_type == "Ride":
        compiler = compile_ride_line
    elif intervals_type == "Swim":
        compiler = compile_swim_line

    for section_name, lines in sections:
        compiled_lines = []

        for line in lines:
            result = compiler(line)

            if result.get("error"):
                warnings.append(result["error"])
                continue

            if result.get("warning"):
                warnings.append(result["warning"])

            if "repeat" in result:
                if compiled_lines:
                    output.append(section_name)
                    output.extend(compiled_lines)
                    compiled_lines = []

                output.append("")
                output.append(f"{result['repeat']}x")
                output.extend(result["steps"])
            else:
                compiled_lines.extend(result.get("steps", []))

        if compiled_lines:
            output.append(section_name)
            output.extend(compiled_lines)

        output.append("")

    while output and not output[-1].strip():
        output.pop()

    if not output:
        raise ValueError("Aucune étape n'a pu être compilée depuis Détails séance.")

    return "\n".join(output), warnings

def estimate_duration_seconds(workout_text):
    total = 0
    repeat = 1

    for line in workout_text.splitlines():
        l = line.strip()
        if not l:
            continue

        m_rep = re.fullmatch(r"(\d+)x", l, flags=re.I)
        if m_rep:
            repeat = int(m_rep.group(1))
            continue

        if not l.startswith("-"):
            repeat = 1
            continue

        m = re.match(r"-\s*(\d+)h", l)
        if m:
            total += int(m.group(1)) * 3600 * repeat
            continue

        m = re.match(r"-\s*(\d+)m(\d+)s", l)
        if m:
            total += (int(m.group(1)) * 60 + int(m.group(2))) * repeat
            continue

        m = re.match(r"-\s*(\d+)m\b", l)
        if m:
            total += int(m.group(1)) * 60 * repeat
            continue

        m = re.match(r"-\s*(\d+)s\b", l)
        if m:
            total += int(m.group(1)) * repeat
            continue

    return total or None

def page_to_event(page):
    props = page.get("properties", {})

    workout_date = get_date(get_prop(props, PROPERTY_DATE, "Date", "Date planifiée"))
    sport_raw = get_plain_text(get_prop(props, PROPERTY_SPORT, "Sport")).strip()
    name = get_plain_text(get_prop(props, PROPERTY_NAME, "Séance", "Seance", "Nom")).strip()
    details = get_plain_text(get_prop(props, PROPERTY_DETAILS, "Détails séance", "Details séance", "Détails", "Details")).strip()
    session_id = get_plain_text(get_prop(props, PROPERTY_ID, "ID séance", "ID Séance", "ID seance", "ID Seance")).strip()

    if not workout_date:
        raise ValueError("Date manquante")
    if not sport_raw:
        raise ValueError("Sport manquant")
    if not name:
        raise ValueError("Séance/Nom manquant")
    if not details:
        raise ValueError("Détails séance manquant")
    if not session_id:
        raise ValueError("ID séance manquant")

    intervals_type = SPORT_MAP.get(sport_raw, SPORT_MAP.get(sport_raw.capitalize()))
    if not intervals_type:
        raise ValueError(f"Sport non reconnu : {sport_raw}")

    description, warnings = compile_details(details, intervals_type)
    moving_time = estimate_duration_seconds(description)

    event = {
        "category": "WORKOUT",
        "start_date_local": f"{workout_date}T00:00:00",
        "name": name,
        "type": intervals_type,
        "description": description,
        "external_id": session_id,
    }
    if moving_time:
        event["moving_time"] = moving_time

    return event, warnings

def post_events_to_intervals(api_key, events):
    url = "https://intervals.icu/api/v1/athlete/0/events/bulk?upsert=true"
    return http_json("POST", url, headers=intervals_headers(api_key), payload=events)





# =========================
# V7 settings and compiler
# =========================

V6_CONFIG_PATH = Path.home() / ".notion_to_intervals_v7.json"

APPDATA_DIR = Path(os.getenv("APPDATA", str(Path.home()))) / "WorkoutSync"
CREDENTIALS_FILE = APPDATA_DIR / "credentials.json"

def load_credentials():
    if not CREDENTIALS_FILE.exists():
        return {}
    try:
        return json.loads(CREDENTIALS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_credentials(notion_token, intervals_api_key, database_id):
    APPDATA_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "notion_token": notion_token.strip(),
        "intervals_api_key": intervals_api_key.strip(),
        "database_id": database_id.strip(),
    }
    CREDENTIALS_FILE.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

def clear_credentials():
    try:
        CREDENTIALS_FILE.unlink(missing_ok=True)
    except Exception:
        pass

APP_VERSION = "7.4"

DEFAULT_PROFILE = {
    "ftp": 260,
    "ftp_pct_enabled": True,
    "ftp_pct": 3.0,
    "im_power": 190,
    "im_power_pct_enabled": True,
    "im_power_pct": 3.0,
    "ef_pace": "5:20",
    "ef_pace_pct_enabled": True,
    "ef_pace_pct": 5.0,
    "marathon_pace": "4:15",
    "marathon_pace_pct_enabled": True,
    "marathon_pace_pct": 2.0,
    "threshold_pace": "3:55",
    "threshold_pace_pct_enabled": True,
    "threshold_pace_pct": 2.0,
}

def load_v6_config():
    data = {"database_id": DEFAULT_DATABASE_ID, "profile": DEFAULT_PROFILE.copy()}
    if V6_CONFIG_PATH.exists():
        try:
            saved = json.loads(V6_CONFIG_PATH.read_text(encoding="utf-8"))
            data.update({k: v for k, v in saved.items() if k != "profile"})
            profile = DEFAULT_PROFILE.copy()
            profile.update(saved.get("profile", {}))
            data["profile"] = profile
        except Exception:
            pass
    return data

def save_v6_config(database_id, profile):
    V6_CONFIG_PATH.write_text(
        json.dumps(
            {"database_id": database_id, "profile": profile},
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

def clean_training_line(line):
    line = normalize_text(line).strip()
    replacements = [
        (r"\bkilom[eè]tres?\b", "km"),
        (r"\bm[eè]tres?\b", "m"),
        (r"\bheures?\b", "h"),
        (r"\bminutes?\b", "min"),
        (r"\bsecondes?\b", "s"),
        (r"\bsecs?\b", "s"),
    ]
    for pattern, replacement in replacements:
        line = re.sub(pattern, replacement, line, flags=re.I)
    line = re.sub(r"\s+", " ", line)
    return re.sub(r"[\s\.,;:]+$", "", line).strip()

def pace_seconds(pace):
    p = normalize_pace(str(pace))
    minutes, seconds = p.split(":")
    return int(minutes) * 60 + int(seconds)

def pace_from_seconds(seconds):
    seconds = max(1, int(round(seconds)))
    return f"{seconds // 60}:{seconds % 60:02d}"

def target_bounds(value, pct, kind):
    if kind == "power":
        v = float(value)
        return int(round(v * (1 - pct / 100))), int(round(v * (1 + pct / 100)))
    seconds = pace_seconds(value)
    return (
        pace_from_seconds(seconds * (1 - pct / 100)),
        pace_from_seconds(seconds * (1 + pct / 100)),
    )

def profile_target(profile, key, kind):
    value = profile[key]
    enabled = profile.get(f"{key}_pct_enabled", False)
    pct = float(profile.get(f"{key}_pct", 0) or 0)
    if not enabled or pct <= 0:
        return f"{value}w" if kind == "power" else f"{normalize_pace(str(value))} Pace"
    low, high = target_bounds(value, pct, kind)
    return f"{low}-{high}w" if kind == "power" else f"{low}-{high} Pace"

def format_distance_for_intervals(value, unit):
    numeric = float(str(value).replace(",", "."))
    if unit.lower() == "m":
        numeric /= 1000.0
    if numeric.is_integer():
        return f"{int(numeric)}km"
    return f"{numeric:.3f}".rstrip("0").rstrip(".") + "km"

def duration_expression_to_seconds(raw):
    value = clean_training_line(raw).lower().replace(" ", "")
    m = re.fullmatch(r"(?P<h>\d+)h(?P<m>\d{1,2})?", value)
    if m:
        return int(m.group("h")) * 3600 + int(m.group("m") or 0) * 60
    m = re.fullmatch(r"(?P<m>\d+)(?:min|m|')", value)
    if m:
        return int(m.group("m")) * 60
    m = re.fullmatch(r'(?P<s>\d+)(?:s|")', value)
    if m:
        return int(m.group("s"))
    raise ValueError(f"Durée non reconnue : {raw}")

def seconds_to_intervals_duration(seconds):
    seconds = int(seconds)
    if seconds % 3600 == 0:
        return f"{seconds // 3600}h"
    if seconds >= 60:
        minutes, remainder = divmod(seconds, 60)
        return f"{minutes}m{remainder}s" if remainder else f"{minutes}m"
    return f"{seconds}s"

def duration_token(raw):
    return seconds_to_intervals_duration(duration_expression_to_seconds(raw))

def upper_duration(d1, d2, unit=None):
    raw1 = f"{d1}{unit or ''}"
    raw2 = f"{d2}{unit or ''}"
    return seconds_to_intervals_duration(
        max(duration_expression_to_seconds(raw1), duration_expression_to_seconds(raw2))
    )

def split_plus_segments(line):
    return [part.strip() for part in re.split(r"\s+\+\s+", line) if part.strip()]

def is_instruction_note(line):
    low = clean_training_line(line).lower()
    measurable = [
        r"\b\d+\s*(?:h|min|m|km|s|['\"])\b",
        r"\b\d+\s+(?:à|a|-)\s+\d+\s*(?:h|min|m|s|['\"])\b",
        r"\b\d+\s*x\s*\d+",
        r"\b\d+\s*w\b",
        r"\b\d+\s*%\b",
        r"\b\d+\s*rpm\b",
        r"\bz[1-7]\b",
        r"\b\d+[':]\d{1,2}\b",
        r"\b(?:récupération|recuperation|récup|recup|r=)\s*\d+",
    ]
    return not any(re.search(pattern, low, flags=re.I) for pattern in measurable)

def result_steps(*steps, warning=None, repeat=None):
    result = {"steps": list(steps)}
    if warning:
        result["warning"] = warning
    if repeat is not None:
        result["repeat"] = int(repeat)
    return result

# -------------------------
# Running parser rules
# -------------------------

def run_rule_compound(line, profile):
    parts = split_plus_segments(line)
    if len(parts) <= 1:
        return None
    steps, warnings = [], []
    for part in parts:
        result = compile_running_line_v7(part, profile)
        if result.get("error") or result.get("repeat"):
            return {"error": f"Ligne composée non prise en charge : {line}"}
        steps.extend(result.get("steps", []))
        if result.get("warning"):
            warnings.append(result["warning"])
    return result_steps(*steps, warning=" / ".join(warnings) if warnings else None)

def _recovery_to_interval(value, unit, seconds_part=None):
    unit = "'" if unit == "’" else unit
    if unit in ("'", "min", "m"):
        total = int(value) * 60
    else:
        total = int(value)
    if seconds_part:
        total += int(seconds_part)
    return seconds_to_intervals_duration(total)


def run_rule_repeat_distance_pace_inline_recovery(line, profile):
    """5 x 1000 m à 3'50/km, récupération 2'."""
    m = re.fullmatch(
        r"(?P<count>\d+)\s*x\s*"
        r"(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>m|km)"
        r".*?(?:à|a|@)\s*"
        r"(?P<p1>\d+(?:[':]\d{1,2}|['’]))"
        r"(?:\s*-\s*(?P<p2>\d+(?:[':]\d{1,2}|['’])))?"
        r"(?:\s*/?\s*km)?"
        r".*?(?:récupération|recuperation|récup|recup|repos|r=)\s*"
        r"(?P<rec>\d+)\s*(?P<recunit>'|’|min|m|s|\")"
        r"(?:(?P<recsec>\d+)\s*(?:s|\"))?"
        r"(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None

    target = normalize_pace(m.group("p1"))
    if m.group("p2"):
        target += f"-{normalize_pace(m.group('p2'))}"

    return result_steps(
        f"- {format_distance_for_intervals(m.group('dist'), m.group('unit'))} {target} Pace",
        f"- {_recovery_to_interval(m.group('rec'), m.group('recunit'), m.group('recsec'))}",
        repeat=m.group("count"),
    )


def run_rule_repeat_time_pace_inline_recovery(line, profile):
    """3 x 10' à 4'05-4'10/km récupération 3'."""
    m = re.fullmatch(
        r"(?P<count>\d+)\s*x\s*"
        r"(?P<dur>\d+)\s*(?P<unit>'|’|min|s|\")"
        r".*?(?:à|a|@)\s*"
        r"(?P<p1>\d+(?:[':]\d{1,2}|['’]))"
        r"(?:\s*-\s*(?P<p2>\d+(?:[':]\d{1,2}|['’])))?"
        r"(?:\s*/?\s*km)?"
        r".*?(?:récupération|recuperation|récup|recup|repos|r=)\s*"
        r"(?P<rec>\d+)\s*(?P<recunit>'|’|min|m|s|\")"
        r"(?:(?P<recsec>\d+)\s*(?:s|\"))?"
        r"(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None

    target = normalize_pace(m.group("p1"))
    if m.group("p2"):
        target += f"-{normalize_pace(m.group('p2'))}"

    effort_unit = "'" if m.group("unit") == "’" else m.group("unit")
    return result_steps(
        f"- {normalize_duration(m.group('dur'), effort_unit)} {target} Pace",
        f"- {_recovery_to_interval(m.group('rec'), m.group('recunit'), m.group('recsec'))}",
        repeat=m.group("count"),
    )


def run_rule_repeat_distance_inline_recovery(line, profile):
    """5 x 1000 m, récupération 400 m ou 2'."""
    m = re.fullmatch(
        r"(?P<count>\d+)\s*x\s*"
        r"(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>m|km)"
        r".*?(?:récupération|recuperation|récup|recup|repos|r=)\s*"
        r"(?P<rec>\d+)\s*(?P<recunit>'|’|min|m|s|\")"
        r"(?:(?P<recsec>\d+)\s*(?:s|\"))?"
        r"(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None

    return result_steps(
        f"- {format_distance_for_intervals(m.group('dist'), m.group('unit'))}",
        f"- {_recovery_to_interval(m.group('rec'), m.group('recunit'), m.group('recsec'))}",
        repeat=m.group("count"),
    )


def run_rule_repeat_time_inline_recovery(line, profile):
    """4 x 20" relâchées, récupération 1'."""
    m = re.fullmatch(
        r"(?P<count>\d+)\s*x\s*"
        r"(?P<dur>\d+)\s*(?P<unit>'|’|min|s|\")"
        r".*?(?:récupération|recuperation|récup|recup|repos|r=)\s*"
        r"(?P<rec>\d+)\s*(?P<recunit>'|’|min|m|s|\")"
        r"(?:(?P<recsec>\d+)\s*(?:s|\"))?"
        r"(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None

    effort_unit = "'" if m.group("unit") == "’" else m.group("unit")
    return result_steps(
        f"- {normalize_duration(m.group('dur'), effort_unit)}",
        f"- {_recovery_to_interval(m.group('rec'), m.group('recunit'), m.group('recsec'))}",
        repeat=m.group("count"),
    )


def run_rule_repeat_time_pace(line, profile):
    m = re.fullmatch(
        r"(?P<count>\d+)\s*x\s*(?P<dur>\d+)\s*(?P<unit>'|min|m|s|\")"
        r".*?(?:à|a|@)\s*(?P<p1>\d+(?:[':]\d{1,2}|['’]))"
        r"(?:\s*-\s*(?P<p2>\d+(?:[':]\d{1,2}|['’])))?"
        r"(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    target = normalize_pace(m.group("p1"))
    if m.group("p2"):
        target += f"-{normalize_pace(m.group('p2'))}"
    return result_steps(
        f"- {normalize_duration(m.group('dur'), m.group('unit'))} {target} Pace",
        repeat=m.group("count"),
    )

def run_rule_repeat_distance_pace(line, profile):
    m = re.fullmatch(
        r"(?P<count>\d+)\s*x\s*(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>m|km)"
        r".*?(?:à|a|@)\s*(?P<p1>\d+(?:[':]\d{1,2}|['’]))"
        r"(?:\s*-\s*(?P<p2>\d+(?:[':]\d{1,2}|['’])))?"
        r"(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    target = normalize_pace(m.group("p1"))
    if m.group("p2"):
        target += f"-{normalize_pace(m.group('p2'))}"
    return result_steps(
        f"- {format_distance_for_intervals(m.group('dist'), m.group('unit'))} {target} Pace",
        repeat=m.group("count"),
    )

def run_rule_repeat_distance_simple(line, profile):
    m = re.fullmatch(
        r"(?P<count>\d+)\s*x\s*(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>m|km)"
        r"(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    return result_steps(
        f"- {format_distance_for_intervals(m.group('dist'), m.group('unit'))}",
        repeat=m.group("count"),
        warning="Récupération non précisée : aucune récupération ajoutée.",
    )

def run_rule_repeat_simple(line, profile):
    m = re.fullmatch(
        r"(?P<count>\d+)\s*x\s*(?P<dur>\d+)\s*(?P<unit>s|\"|'|min|m)(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None

    effort = normalize_duration(m.group("dur"), m.group("unit"))
    effort_seconds = duration_expression_to_seconds(
        f"{m.group('dur')}{m.group('unit')}"
    )

    # Efforts courts : récupération automatique égale à l'effort.
    if effort_seconds < 60:
        return result_steps(
            f"- {effort}",
            f"- {effort}",
            repeat=m.group("count"),
        )

    # À partir d'une minute, aucune récupération n'est inventée.
    return result_steps(
        f"- {effort}",
        repeat=m.group("count"),
        warning="Récupération non précisée : aucune récupération ajoutée.",
    )

def run_rule_variable_with_pace(line, profile):
    m = re.fullmatch(
        r"(?P<d1>\d+h\d{0,2}|\d+)\s+(?:à|a|-)\s+"
        r"(?P<d2>\d+h\d{0,2}|\d+)\s*(?P<unit>'|min|m)?"
        r".*?(?:à|a|@)\s*(?P<p1>\d+(?:[':]\d{1,2}|['’]))"
        r"(?:\s*-\s*(?P<p2>\d+(?:[':]\d{1,2}|['’])))?"
        r"(?:\s*/?\s*km)?(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    target = normalize_pace(m.group("p1"))
    if m.group("p2"):
        target += f"-{normalize_pace(m.group('p2'))}"
    return result_steps(
        f"- {upper_duration(m.group('d1'), m.group('d2'), m.group('unit'))} {target} Pace",
        warning="Durée variable : borne haute utilisée, allure conservée.",
    )

def run_rule_variable_simple(line, profile):
    m = re.fullmatch(
        r"(?P<d1>\d+h\d{0,2}|\d+)\s+(?:à|a|-)\s+"
        r"(?P<d2>\d+h\d{0,2}|\d+)\s*(?P<unit>'|min|m)?(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    return result_steps(
        f"- {upper_duration(m.group('d1'), m.group('d2'), m.group('unit'))}",
        warning="Durée variable : borne haute utilisée, sans cible.",
    )

def run_rule_profile_target(line, profile):
    m = re.search(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))"
        r".*?\b(?P<label>EF|endurance fondamentale|AS42|AM|allure marathon|marathon|seuil)\b",
        line,
        flags=re.I,
    )
    if not m:
        return None
    label = m.group("label").lower()
    if label in ["ef", "endurance fondamentale"]:
        key = "ef_pace"
    elif label in ["as42", "am", "allure marathon", "marathon"]:
        key = "marathon_pace"
    else:
        key = "threshold_pace"
    return result_steps(
        f"- {duration_token(m.group('dur'))} {profile_target(profile, key, 'pace')}"
    )

def run_rule_zone(line, profile):
    m = re.fullmatch(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))"
        r".*?\b(?P<zone>Z[1-7]|Sweet Spot|Tempo)\b(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if m:
        return result_steps(f"- {duration_token(m.group('dur'))} {m.group('zone')}")
    m = re.fullmatch(
        r"(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>m|km)"
        r".*?\b(?P<zone>Z[1-7]|Sweet Spot|Tempo)\b(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if m:
        return result_steps(
            f"- {format_distance_for_intervals(m.group('dist'), m.group('unit'))} {m.group('zone')}"
        )
    return None

def run_rule_inequality_pace(line, profile):
    m = re.fullmatch(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))"
        r".*?(?P<op><|>|plus vite que|moins vite que)\s*"
        r"(?P<pace>\d+(?:[':]\d{1,2}|['’']))(?:\s*/?\s*km)?(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    return result_steps(
        f"- {duration_token(m.group('dur'))} {normalize_pace(m.group('pace'))} Pace",
        warning=f"Borne d’allure « {m.group('op')} » approximée avec la valeur frontière.",
    )

def run_rule_explicit_pace(line, profile):
    # Distance first, otherwise "1000 m" could be misread as 1000 minutes.
    m = re.search(
        r"(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>m|km)"
        r".*?(?:à|a|@)\s*(?P<p1>\d+(?:[':]\d{1,2}|['’]))"
        r"(?:\s*-\s*(?P<p2>\d+(?:[':]\d{1,2}|['’])))?",
        line,
        flags=re.I,
    )
    if m:
        target = normalize_pace(m.group("p1"))
        if m.group("p2"):
            target += f"-{normalize_pace(m.group('p2'))}"
        return result_steps(
            f"- {format_distance_for_intervals(m.group('dist'), m.group('unit'))} {target} Pace"
        )

    m = re.search(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|s|\"))"
        r".*?(?:à|a|@)\s*(?P<p1>\d+(?:[':]\d{1,2}|['’]))"
        r"(?:\s*-\s*(?P<p2>\d+(?:[':]\d{1,2}|['’])))?(?:\s*/?\s*km)?",
        line,
        flags=re.I,
    )
    if m:
        target = normalize_pace(m.group("p1"))
        if m.group("p2"):
            target += f"-{normalize_pace(m.group('p2'))}"
        return result_steps(f"- {duration_token(m.group('dur'))} {target} Pace")

    return None

def run_rule_simple(line, profile):
    m = re.fullmatch(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if m:
        return result_steps(f"- {duration_token(m.group('dur'))}")
    m = re.fullmatch(
        r"(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>m|km)(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if m:
        return result_steps(
            f"- {format_distance_for_intervals(m.group('dist'), m.group('unit'))}"
        )
    return None

RUN_RULES = [
    run_rule_compound,
    run_rule_repeat_distance_pace_inline_recovery,
    run_rule_repeat_time_pace_inline_recovery,
    run_rule_repeat_distance_inline_recovery,
    run_rule_repeat_time_inline_recovery,
    run_rule_repeat_time_pace,
    run_rule_repeat_distance_pace,
    run_rule_repeat_distance_simple,
    run_rule_repeat_simple,
    run_rule_variable_with_pace,
    run_rule_variable_simple,
    run_rule_profile_target,
    run_rule_zone,
    run_rule_inequality_pace,
    run_rule_explicit_pace,
    run_rule_simple,
]

def compile_running_line_v7(line, profile):
    cleaned = clean_training_line(line)
    for rule in RUN_RULES:
        result = rule(cleaned, profile)
        if result is not None:
            return result
    return {"error": f"Ligne running non comprise : {cleaned}"}

# -------------------------
# Cycling parser rules
# -------------------------

def ride_rule_compound(line, profile):
    parts = split_plus_segments(line)
    if len(parts) <= 1:
        return None
    steps, warnings = [], []
    for part in parts:
        result = compile_ride_line_v7(part, profile)
        if result.get("error") or result.get("repeat"):
            return {"error": f"Ligne composée non prise en charge : {line}"}
        steps.extend(result.get("steps", []))
        if result.get("warning"):
            warnings.append(result["warning"])
    return result_steps(*steps, warning=" / ".join(warnings) if warnings else None)

def ride_rule_repeat_simple(line, profile):
    m = re.fullmatch(
        r"(?P<count>\d+)\s*x\s*(?P<dur>\d+)\s*(?P<unit>s|\"|'|min|m)"
        r"(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None

    effort = normalize_duration(m.group("dur"), m.group("unit"))
    effort_seconds = duration_expression_to_seconds(
        f"{m.group('dur')}{m.group('unit')}"
    )

    # Efforts courts de vélocité, activation ou relâchement :
    # récupération automatique égale à l'effort.
    if effort_seconds < 60:
        return result_steps(
            f"- {effort}",
            f"- {effort}",
            repeat=m.group("count"),
        )

    return result_steps(
        f"- {effort}",
        repeat=m.group("count"),
        warning="Récupération non précisée : aucune récupération ajoutée.",
    )

def ride_rule_repeat_power(line, profile):
    m = re.search(
        r"(?P<count>\d+)\s*x\s*(?P<dur>\d+)\s*(?P<unit>'|min|m|s|\")"
        r".*?(?P<p1>\d+)(?:\s*-\s*(?P<p2>\d+))?\s*w",
        line,
        flags=re.I,
    )
    if not m:
        return None
    power = m.group("p1")
    if m.group("p2"):
        power += f"-{m.group('p2')}"
    return result_steps(
        f"- {normalize_duration(m.group('dur'), m.group('unit'))} {power}w",
        repeat=m.group("count"),
    )

def ride_rule_variable_power(line, profile):
    m = re.fullmatch(
        r"(?P<d1>\d+h\d{0,2}|\d+)\s+(?:à|a|-)\s+"
        r"(?P<d2>\d+h\d{0,2}|\d+)\s*(?P<unit>'|min|m)?"
        r".*?(?P<p1>\d+)\s*-\s*(?P<p2>\d+)\s*w(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    return result_steps(
        f"- {upper_duration(m.group('d1'), m.group('d2'), m.group('unit'))} "
        f"{m.group('p1')}-{m.group('p2')}w",
        warning="Durée variable : borne haute utilisée, puissance conservée.",
    )

def ride_rule_variable_simple(line, profile):
    m = re.fullmatch(
        r"(?P<d1>\d+h\d{0,2}|\d+)\s+(?:à|a|-)\s+"
        r"(?P<d2>\d+h\d{0,2}|\d+)\s*(?P<unit>'|min|m)?(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    return result_steps(
        f"- {upper_duration(m.group('d1'), m.group('d2'), m.group('unit'))}",
        warning="Durée variable : borne haute utilisée, sans cible.",
    )

def ride_rule_im_power(line, profile):
    m = re.search(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))"
        r".*?\b(?:puissance IM|allure IM|ironman)\b",
        line,
        flags=re.I,
    )
    if not m:
        return None
    return result_steps(
        f"- {duration_token(m.group('dur'))} {profile_target(profile, 'im_power', 'power')}"
    )

def ride_rule_zone(line, profile):
    m = re.fullmatch(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))"
        r".*?\b(?P<zone>Z[1-7]|Sweet Spot|Tempo)\b(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    return result_steps(f"- {duration_token(m.group('dur'))} {m.group('zone')}")

def ride_rule_power(line, profile):
    m = re.search(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))"
        r".*?(?P<p1>\d+)(?:\s*-\s*(?P<p2>\d+))?\s*w",
        line,
        flags=re.I,
    )
    if not m:
        return None
    power = m.group("p1")
    if m.group("p2"):
        power += f"-{m.group('p2')}"
    return result_steps(f"- {duration_token(m.group('dur'))} {power}w")

def ride_rule_cadence(line, profile):
    m = re.search(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))"
        r".*?(?P<c1>\d+)(?:\s*-\s*(?P<c2>\d+))?\s*rpm",
        line,
        flags=re.I,
    )
    if not m:
        return None
    cadence = f"{m.group('c1')}-{m.group('c2')}rpm" if m.group("c2") else f"{m.group('c1')}rpm"
    return result_steps(f"- {duration_token(m.group('dur'))} {cadence}")

def ride_rule_inequality_power(line, profile):
    m = re.fullmatch(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))"
        r".*?(?P<op><|>|inf[eé]rieur[e]?\s+à|sup[eé]rieur[e]?\s+à|moins de|plus de)"
        r"\s*(?P<power>\d+)\s*w(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    return result_steps(
        f"- {duration_token(m.group('dur'))} {m.group('power')}w",
        warning=f"Borne de puissance « {m.group('op')} » approximée avec la valeur frontière.",
    )

def ride_rule_simple(line, profile):
    m = re.fullmatch(
        r"(?P<dur>\d+h\d{0,2}(?:min|m)?|\d+\s*(?:'|min|m|s|\"))(?:\s+.*)?",
        line,
        flags=re.I,
    )
    if not m:
        return None
    return result_steps(f"- {duration_token(m.group('dur'))}")

RIDE_RULES = [
    ride_rule_compound,
    ride_rule_repeat_power,
    ride_rule_repeat_simple,
    ride_rule_variable_power,
    ride_rule_variable_simple,
    ride_rule_im_power,
    ride_rule_zone,
    ride_rule_inequality_power,
    ride_rule_power,
    ride_rule_cadence,
    ride_rule_simple,
]

def compile_ride_line_v7(line, profile):
    cleaned = clean_training_line(line)
    for rule in RIDE_RULES:
        result = rule(cleaned, profile)
        if result is not None:
            return result
    return {"error": f"Ligne vélo non comprise : {cleaned}"}

def compile_details_v7(details, intervals_type, profile):
    forced = re.search(r"INTERVALS\s*:\s*(.*)", details, flags=re.I | re.S)
    if forced:
        script = forced.group(1).strip()
        return script, [], [{"status": "ok", "source": "Bloc INTERVALS manuel", "output": script}]

    sections = split_sections(details)
    output, warnings, records = [], [], []
    compiler = (
        (lambda line: compile_running_line_v7(line, profile))
        if intervals_type == "Run"
        else (lambda line: compile_ride_line_v7(line, profile))
    )

    for section_name, lines in sections:
        section_output = []
        last_repeat = None

        for raw_line in lines:
            line = clean_training_line(raw_line)

            # Recovery by distance.
            m = re.fullmatch(
                r"(?:récupération|recuperation|récup|recup|repos)"
                r"(?:\s+entre.*?|\s*:|\s*)"
                r"(?P<dist>\d+(?:[.,]\d+)?)\s*(?P<unit>m|km)(?:\s+.*)?",
                line,
                flags=re.I,
            )
            if m and last_repeat is not None:
                step = f"- {format_distance_for_intervals(m.group('dist'), m.group('unit'))}"
                output.append(step)
                last_repeat["record"]["output"] += f"\n{step}"
                records.append({
                    "status": "ok",
                    "source": raw_line,
                    "output": "Récupération en distance rattachée à la répétition précédente.",
                })
                continue

            # Recovery by time.
            m = re.fullmatch(
                r"(?:récupération|recuperation|récup|recup|repos)"
                r"(?:\s+entre.*?|\s*:|\s*)"
                r"(?P<rec>\d+)\s*(?P<unit>'|min|m|s|\")?(?:\s+.*)?",
                line,
                flags=re.I,
            )
            if m and last_repeat is not None:
                unit = m.group("unit") or "'"
                step = f"- {normalize_duration(m.group('rec'), unit)}"
                output.append(step)
                last_repeat["record"]["output"] += f"\n{step}"
                records.append({
                    "status": "ok",
                    "source": raw_line,
                    "output": "Récupération rattachée à la répétition précédente.",
                })
                continue

            # Complete recovery = same time as effort.
            if re.search(
                r"(?:récupération|recuperation|récup|recup|repos)\s+compl[eè]te",
                line,
                flags=re.I,
            ) and last_repeat is not None:
                effort = last_repeat["steps"][0]
                duration_match = re.match(r"-\s*(\d+h|\d+m(?:\d+s)?|\d+s)", effort)
                if duration_match:
                    step = f"- {duration_match.group(1)}"
                    output.append(step)
                    last_repeat["record"]["output"] += f"\n{step}"
                    records.append({
                        "status": "ok",
                        "source": raw_line,
                        "output": "Récupération complète = même durée que l’intervalle.",
                    })
                    continue

            result = compiler(line)

            if result.get("error"):
                if is_instruction_note(line):
                    records.append({
                        "status": "note",
                        "source": raw_line,
                        "output": "Information ignorée : aucune étape Garmin à créer.",
                    })
                else:
                    records.append({
                        "status": "error",
                        "source": raw_line,
                        "output": result["error"],
                    })
                continue

            status = "warning" if result.get("warning") else "ok"
            if result.get("warning"):
                warnings.append(result["warning"])

            if "repeat" in result:
                if section_output:
                    output.append(section_name)
                    output.extend(section_output)
                    section_output = []
                output.append("")
                output.append(f"{result['repeat']}x")
                output.extend(result["steps"])
                record = {
                    "status": status,
                    "source": raw_line,
                    "output": "\n".join([f"{result['repeat']}x"] + result["steps"]),
                }
                records.append(record)
                last_repeat = {"steps": result["steps"], "record": record}
            else:
                section_output.extend(result["steps"])
                records.append({
                    "status": status,
                    "source": raw_line,
                    "output": "\n".join(result["steps"]),
                })
                last_repeat = None

        if section_output:
            output.append(section_name)
            output.extend(section_output)
        output.append("")

    while output and not output[-1].strip():
        output.pop()

    if not output:
        raise ValueError("Aucune étape n'a pu être compilée depuis Détails séance.")

    script = "\n".join(output)

    source_repeats = len(re.findall(r"\b\d+\s*x\s*\d+", normalize_text(details), flags=re.I))
    script_repeats = len(re.findall(r"^\s*\d+x\s*$", script, flags=re.I | re.M))
    if script_repeats < source_repeats:
        records.append({
            "status": "error",
            "source": "Contrôle de cohérence",
            "output": (
                f"{source_repeats} répétition(s) détectée(s) dans la source, "
                f"seulement {script_repeats} dans le script."
            ),
        })

    return script, warnings, records

# Backward-compatible name used by the UI.
compile_details_v6 = compile_details_v7
class App(tk.Tk):
    ORANGE = "#D8742A"
    ORANGE_DARK = "#B85F1E"
    BLACK = "#0B0B0B"
    WHITE = "#FFFFFF"
    BG = "#F3F3F3"
    MUTED = "#6B7280"

    def __init__(self):
        super().__init__()
        self.title("Workout Sync V7.4")
        self.geometry("1450x920")
        self.minsize(1220, 780)
        self.configure(bg=self.BG)

        self.sources = []
        self.current_source = None
        self.checked_ids = set()
        self.current_records = []
        self.logs = []

        cfg = load_v6_config()
        credentials = load_credentials()
        self.profile = cfg["profile"]
        self.saved_credentials = credentials
        self._styles()
        self._topbar(cfg)
        self._navbar()
        self._main()
        self._statusbar()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def save_credentials_now(self):
        save_credentials(
            self.notion_token.get(),
            self.intervals_key.get(),
            self.database_id.get(),
        )
        self.log("Identifiants enregistrés sur cet ordinateur")

    def clear_saved_credentials(self):
        if not messagebox.askyesno(
            "Effacer les identifiants",
            "Effacer les identifiants enregistrés sur cet ordinateur ?"
        ):
            return
        clear_credentials()
        self.notion_token.set("")
        self.intervals_key.set("")
        self.database_id.set(DEFAULT_DATABASE_ID)
        self.log("Identifiants enregistrés effacés")

    def on_close(self):
        try:
            save_credentials(
                self.notion_token.get(),
                self.intervals_key.get(),
                self.database_id.get(),
            )
        finally:
            self.destroy()

    def _styles(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except Exception:
            pass
        s.configure("Root.TFrame", background=self.BG)
        s.configure("White.TFrame", background=self.WHITE)
        s.configure("Black.TFrame", background=self.BLACK)
        s.configure("Orange.TFrame", background=self.ORANGE)
        s.configure("Hero.TLabel", background=self.ORANGE, foreground=self.WHITE, font=("Segoe UI Semibold", 18))
        s.configure("HeroSub.TLabel", background=self.ORANGE, foreground="#FFF4EA", font=("Segoe UI", 10))
        s.configure("CardTitle.TLabel", background=self.BLACK, foreground=self.WHITE, font=("Arial Narrow", 15, "bold"))
        s.configure("Card.TLabel", background=self.WHITE, foreground=self.BLACK, font=("Segoe UI", 10))
        s.configure("Muted.TLabel", background=self.WHITE, foreground=self.MUTED, font=("Segoe UI", 9))
        s.configure("Orange.TButton", background=self.ORANGE, foreground=self.WHITE, font=("Segoe UI Semibold", 10), padding=(14, 9))
        s.map("Orange.TButton", background=[("active", self.ORANGE_DARK)])
        s.configure("Black.TButton", background=self.BLACK, foreground=self.WHITE, font=("Segoe UI Semibold", 10), padding=(14, 9))
        s.configure("White.TButton", background=self.WHITE, foreground=self.BLACK, font=("Segoe UI", 10), padding=(12, 8))
        s.configure("TEntry", padding=7)
        s.configure("Treeview", rowheight=30, font=("Segoe UI", 9), background=self.WHITE)
        s.configure("Treeview.Heading", font=("Segoe UI Semibold", 9), background="#F8F8F8")

    def _topbar(self, cfg):
        top = ttk.Frame(self, style="Orange.TFrame")
        top.pack(fill="x")
        brand = ttk.Frame(top, style="Orange.TFrame")
        brand.pack(side="left", padx=24, pady=15)
        ttk.Label(brand, text="WORKOUT SYNC", style="Hero.TLabel").pack(anchor="w")
        ttk.Label(brand, text="NOTION → INTERVALS.ICU → GARMIN", style="HeroSub.TLabel").pack(anchor="w")

        form = ttk.Frame(top, style="Orange.TFrame")
        form.pack(side="right", padx=24, pady=12)
        self.notion_token = tk.StringVar(
            value=self.saved_credentials.get("notion_token", "")
        )
        self.intervals_key = tk.StringVar(
            value=self.saved_credentials.get("intervals_api_key", "")
        )
        self.database_id = tk.StringVar(
            value=self.saved_credentials.get(
                "database_id",
                cfg.get("database_id", DEFAULT_DATABASE_ID)
            )
        )
        for col, (label, var, width, show) in enumerate([
            ("Notion token", self.notion_token, 26, "*"),
            ("Intervals API key", self.intervals_key, 22, "*"),
            ("Database ID", self.database_id, 31, ""),
        ]):
            ttk.Label(form, text=label, background=self.ORANGE, foreground=self.WHITE,
                      font=("Segoe UI Semibold", 9)).grid(row=0, column=col, sticky="w", padx=(8, 0))
            ttk.Entry(form, textvariable=var, width=width, show=show).grid(row=1, column=col, padx=(8, 0), pady=(3, 0))

    def _navbar(self):
        nav = ttk.Frame(self, style="White.TFrame")
        nav.pack(fill="x")
        ttk.Button(nav, text="CHARGER NOTION", style="Black.TButton", command=self.load_notion).pack(side="left", padx=(24, 8), pady=10)
        ttk.Button(nav, text="+ AJOUTER UNE SÉANCE", style="Orange.TButton", command=self.add_manual).pack(side="left", padx=4, pady=10)
        ttk.Button(nav, text="RÉGÉNÉRER SCRIPT + PAYLOAD", style="White.TButton", command=self.regenerate_all).pack(side="left", padx=4, pady=10)
        ttk.Button(nav, text="ACTUALISER PAYLOAD", style="White.TButton", command=self.regenerate_payload).pack(side="left", padx=4, pady=10)
        ttk.Button(nav, text="RÉGLAGES", style="Black.TButton", command=self.open_settings).pack(side="left", padx=4, pady=10)
        ttk.Button(nav, text="ENVOYER", style="Orange.TButton", command=self.send).pack(side="right", padx=(8, 24), pady=10)

    def _card(self, parent, title, subtitle):
        card = ttk.Frame(parent, style="White.TFrame")
        h = ttk.Frame(card, style="Black.TFrame")
        h.pack(fill="x")
        ttk.Label(h, text=title.upper(), style="CardTitle.TLabel").pack(side="left", padx=14, pady=10)
        ttk.Label(card, text=subtitle, style="Muted.TLabel").pack(anchor="w", padx=14, pady=(9, 6))
        return card

    def _main(self):
        pane = ttk.PanedWindow(self, orient="horizontal")
        pane.pack(fill="both", expand=True, padx=24, pady=18)
        cols = [ttk.Frame(pane, style="Root.TFrame") for _ in range(3)]
        for c in cols:
            pane.add(c, weight=1)

        card = self._card(cols[0], "Source Notion / manuelle", "Coche les séances à envoyer. La case du haut coche ou décoche tout.")
        card.pack(fill="both", expand=True, padx=(0, 7))

        selectbar = ttk.Frame(card, style="White.TFrame")
        selectbar.pack(fill="x", padx=14, pady=(0, 6))
        self.check_all_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(selectbar, text="Tout sélectionner", variable=self.check_all_var,
                        command=self.toggle_all).pack(side="left")

        self.tree = ttk.Treeview(card, columns=("check", "src", "date", "sport", "name"), show="headings", height=8)
        for col, label, width in [
            ("check", "✓", 35), ("src", "Source", 68), ("date", "Date", 88),
            ("sport", "Sport", 65), ("name", "Nom séance", 205)
        ]:
            self.tree.heading(col, text=label)
            self.tree.column(col, width=width, anchor="center" if col == "check" else "w")
        self.tree.pack(fill="x", padx=14, pady=(0, 10))
        self.tree.bind("<<TreeviewSelect>>", self.select_source)
        self.tree.bind("<Button-1>", self.on_tree_click)
        self.tree.bind("<Double-1>", self.on_double_click)
        self.tree.bind("<Button-3>", self.show_context_menu)
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Supprimer", command=self.delete_selected_source)

        self.source_text = tk.Text(card, wrap="word", undo=True, font=("Segoe UI", 10),
                                   bg="#FAFAFA", relief="flat", padx=12, pady=12)
        self.source_text.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        card = self._card(cols[1], "Script Intervals", "Validation ligne par ligne : vert, orange ou rouge.")
        card.pack(fill="both", expand=True, padx=7)
        self.script_text = tk.Text(card, wrap="none", undo=True, font=("Consolas", 10),
                                   bg=self.BLACK, fg="#F9FAFB", insertbackground=self.WHITE,
                                   relief="flat", padx=12, pady=12, height=18)
        self.script_text.pack(fill="both", expand=True, padx=14, pady=(0, 8))

        stats = ttk.Frame(card, style="White.TFrame")
        stats.pack(fill="x", padx=14, pady=(0, 6))

        ttk.Label(stats, text="VALIDATION", style="Card.TLabel").pack(side="left")

        self.stats_ok = tk.StringVar(value="0")
        self.stats_note = tk.StringVar(value="0")
        self.stats_warning = tk.StringVar(value="0")
        self.stats_error = tk.StringVar(value="0")

        def badge(parent, label, variable, bg, fg):
            frame = tk.Frame(parent, bg=bg, bd=0, highlightthickness=0)
            tk.Label(
                frame, text=label, bg=bg, fg=fg,
                font=("Segoe UI Semibold", 9)
            ).pack(side="left", padx=(8, 4), pady=4)
            tk.Label(
                frame, textvariable=variable, bg=bg, fg=fg,
                font=("Segoe UI Semibold", 9)
            ).pack(side="left", padx=(0, 8), pady=4)
            return frame

        badge(stats, "Erreur", self.stats_error, "#FDECEC", "#B91C1C").pack(side="right", padx=(6, 0))
        badge(stats, "Approx.", self.stats_warning, "#FFF4E5", "#B45309").pack(side="right", padx=(6, 0))
        badge(stats, "Info", self.stats_note, "#E8F1FF", "#2563EB").pack(side="right", padx=(6, 0))
        badge(stats, "Compris", self.stats_ok, "#E8F5E9", "#147A3D").pack(side="right", padx=(6, 0))

        self.validation_text = tk.Text(card, height=11, wrap="word", font=("Segoe UI", 9),
                                       bg="#FAFAFA", relief="flat", padx=10, pady=8, state="disabled")
        self.validation_text.pack(fill="x", padx=14, pady=(5, 14))
        self.validation_text.tag_configure("ok", foreground="#147A3D")
        self.validation_text.tag_configure("note", foreground="#2563EB")
        self.validation_text.tag_configure("warning", foreground="#B45309")
        self.validation_text.tag_configure("error", foreground="#B91C1C")

        card = self._card(cols[2], "Payload Intervals.icu", "Le bouton Envoyer traite toutes les lignes cochées.")
        card.pack(fill="both", expand=True, padx=(7, 0))
        self.payload_text = tk.Text(card, wrap="none", undo=True, font=("Consolas", 9),
                                    bg="#FAFAFA", relief="flat", padx=12, pady=12)
        self.payload_text.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        actions = ttk.Frame(card, style="White.TFrame")
        actions.pack(fill="x", padx=14, pady=(0, 14))
        ttk.Button(actions, text="VALIDER JSON", style="Black.TButton", command=self.validate_json).pack(side="left")
        ttk.Button(actions, text="COPIER", style="White.TButton", command=self.copy_payload).pack(side="left", padx=(8, 0))

    def _statusbar(self):
        bar = ttk.Frame(self, style="Root.TFrame")
        bar.pack(fill="x", padx=24, pady=(0, 14))
        self.status = tk.StringVar(value=f"Version {APP_VERSION} — Prêt")
        ttk.Label(bar, textvariable=self.status, foreground=self.MUTED, background=self.BG).pack(side="left")

    def log(self, message):
        self.logs.append(message)
        self.status.set(message)

    def refresh_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for i, src in enumerate(self.sources):
            mark = "☑" if i in self.checked_ids else "☐"
            self.tree.insert("", "end", iid=str(i), values=(
                mark, "Manuelle" if src["source_type"] == "manual" else "Notion",
                src["date"], src["sport"], src["name"]
            ))
        self.check_all_var.set(bool(self.sources) and len(self.checked_ids) == len(self.sources))

    def toggle_all(self):
        self.checked_ids = set(range(len(self.sources))) if self.check_all_var.get() else set()
        self.refresh_tree()

    def on_tree_click(self, event):
        row = self.tree.identify_row(event.y)
        col = self.tree.identify_column(event.x)
        if row and col == "#1":
            idx = int(row)
            if idx in self.checked_ids:
                self.checked_ids.remove(idx)
            else:
                self.checked_ids.add(idx)
            self.refresh_tree()
            self.tree.selection_set(row)
            self.tree.focus(row)
            self.select_source()
            return "break"

    def load_notion(self):
        if not self.notion_token.get().strip():
            messagebox.showerror("Erreur", "Colle ton token Notion.")
            return
        try:
            pages = query_notion_pages(self.notion_token.get().strip(), self.database_id.get().strip())
            # Recharger Notion réinitialise toutes les modifications locales
            # des entrées Notion. Les entrées manuelles restent en mémoire.
            manuals = [s for s in self.sources if s["source_type"] == "manual"]
            self.current_source = None
            self.sources = manuals
            skipped_swim = 0
            for page in pages:
                props = page.get("properties", {})
                sport_value = get_plain_text(get_prop(props, PROPERTY_SPORT, "Sport")).strip()
                if SPORT_MAP.get(sport_value, SPORT_MAP.get(sport_value.capitalize())) == "Swim":
                    skipped_swim += 1
                    continue
                self.sources.append({
                    "source_type": "notion", "page": page,
                    "date": get_date(get_prop(props, PROPERTY_DATE, "Date", "Date planifiée")),
                    "sport": sport_value,
                    "name": get_plain_text(get_prop(props, PROPERTY_NAME, "Séance", "Seance", "Nom")).strip(),
                    "session_id": get_plain_text(get_prop(props, PROPERTY_ID, "ID séance", "ID Séance")).strip(),
                    "details": get_plain_text(get_prop(props, PROPERTY_DETAILS, "Détails séance", "Détails")).strip(),
                })
            self.checked_ids = {i for i in self.checked_ids if i < len(manuals)}
            save_v6_config(self.database_id.get().strip(), self.profile)
            self.refresh_tree()
            if self.sources:
                self.tree.selection_set("0")
                self.select_source()
            self.log(
                f"{len(pages) - skipped_swim} séance(s) course/vélo chargée(s)"
                + (f" — {skipped_swim} natation exclue(s)" if skipped_swim else "")
            )
        except Exception as exc:
            messagebox.showerror("Erreur Notion", str(exc))

    def save_current_edits(self):
        if not self.current_source:
            return
        self.current_source["edited_details"] = self.source_text.get("1.0", "end").strip()
        self.current_source["edited_script"] = self.script_text.get("1.0", "end").strip()
        self.current_source["edited_payload"] = self.payload_text.get("1.0", "end").strip()
        self.current_source["edited_records"] = list(self.current_records)

    def select_source(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return

        selected = self.sources[int(sel[0])]
        if self.current_source is not selected:
            self.save_current_edits()

        self.current_source = selected
        details = selected.get("edited_details", selected["details"])

        self.source_text.delete("1.0", "end")
        self.source_text.insert("1.0", details)

        if selected.get("edited_script") is not None:
            self.script_text.delete("1.0", "end")
            self.script_text.insert("1.0", selected.get("edited_script", ""))

            self.payload_text.delete("1.0", "end")
            self.payload_text.insert("1.0", selected.get("edited_payload", ""))

            self.set_validation(selected.get("edited_records", []))
        else:
            self.regenerate_all()

    def set_validation(self, records):
        self.current_records = records

        counts = {"ok": 0, "note": 0, "warning": 0, "error": 0}
        for rec in records:
            counts[rec["status"]] = counts.get(rec["status"], 0) + 1

        self.stats_ok.set(str(counts["ok"]))
        self.stats_note.set(str(counts["note"]))
        self.stats_warning.set(str(counts["warning"]))
        self.stats_error.set(str(counts["error"]))

        self.validation_text.configure(state="normal")
        self.validation_text.delete("1.0", "end")
        for rec in records:
            icon = {"ok": "●", "note": "◆", "warning": "▲", "error": "✖"}[rec["status"]]
            self.validation_text.insert("end", f"{icon} {rec['source']}\n", rec["status"])
            self.validation_text.insert("end", f"   → {rec['output']}\n\n", rec["status"])
        self.validation_text.configure(state="disabled")

    def regenerate_all(self):
        if not self.current_source:
            return
        try:
            edited_details = self.source_text.get("1.0", "end").strip()
            self.current_source["edited_details"] = edited_details

            itype = SPORT_MAP.get(
                self.current_source["sport"],
                SPORT_MAP.get(self.current_source["sport"].capitalize())
            )
            script, warnings, records = compile_details_v6(
                edited_details, itype, self.profile
            )

            self.script_text.delete("1.0", "end")
            self.script_text.insert("1.0", script)
            self.current_source["edited_script"] = script
            self.current_source["edited_records"] = list(records)

            self.set_validation(records)
            self.regenerate_payload()
        except Exception as exc:
            messagebox.showerror("Erreur compilation", str(exc))

    def build_event_for_source(self, src, use_current_editor=False):
        itype = SPORT_MAP.get(src["sport"], SPORT_MAP.get(src["sport"].capitalize()))
        if itype == "Swim":
            raise ValueError("La natation est volontairement exclue de l’envoi Garmin.")
        if itype == "Swim":
            raise ValueError("La natation est volontairement exclue de l’envoi Garmin.")

        if use_current_editor:
            self.save_current_edits()

        # Une correction directe du payload est prioritaire et doit être conservée.
        payload_text = src.get("edited_payload")
        if payload_text:
            try:
                payload = json.loads(payload_text)
                if isinstance(payload, list) and len(payload) == 1:
                    return payload[0]
            except Exception:
                if use_current_editor:
                    raise ValueError(f"Le payload modifié de « {src['name']} » n'est pas un JSON valide.")

        script = src.get("edited_script")
        records = src.get("edited_records")

        if script is None or records is None:
            details = src.get("edited_details", src["details"])
            script, _, records = compile_details_v6(details, itype, self.profile)

        if any(r["status"] == "error" for r in records):
            raise ValueError(f"« {src['name']} » contient au moins une ligne rouge.")

        event = {
            "category": "WORKOUT",
            "start_date_local": f"{src['date']}T00:00:00",
            "name": src["name"],
            "type": itype,
            "description": script,
            "external_id": src["session_id"],
        }
        moving = estimate_duration_seconds(script)
        if moving:
            event["moving_time"] = moving
        return event

    def regenerate_payload(self):
        if not self.current_source:
            return
        try:
            self.current_source["edited_script"] = self.script_text.get("1.0", "end").strip()
            self.current_source["edited_records"] = list(self.current_records)

            # Ignore temporairement un ancien payload pour le reconstruire depuis le script.
            old_payload = self.current_source.pop("edited_payload", None)
            event = self.build_event_for_source(self.current_source, False)
            payload_text = json.dumps([event], indent=2, ensure_ascii=False)

            self.payload_text.delete("1.0", "end")
            self.payload_text.insert("1.0", payload_text)
            self.current_source["edited_payload"] = payload_text
        except Exception as exc:
            self.log(str(exc))

    def validate_json(self):
        try:
            payload = json.loads(self.payload_text.get("1.0", "end").strip())
            if not isinstance(payload, list) or not payload:
                raise ValueError("Le payload doit être une liste non vide.")
            messagebox.showinfo("JSON valide", "Le payload est valide.")
        except Exception as exc:
            messagebox.showerror("JSON invalide", str(exc))

    def copy_payload(self):
        self.clipboard_clear()
        self.clipboard_append(self.payload_text.get("1.0", "end").strip())
        self.log("Payload copié")

    def send(self):
        indices = sorted(self.checked_ids)
        if not indices:
            messagebox.showwarning("Aucune sélection", "Coche au moins une séance dans la liste.")
            return
        if not self.intervals_key.get().strip():
            messagebox.showerror("Erreur", "Clé API Intervals manquante.")
            return

        try:
            payload = []
            for idx in indices:
                src = self.sources[idx]
                use_current = src is self.current_source
                payload.append(self.build_event_for_source(src, use_current))

            if not messagebox.askyesno("Confirmation", f"Envoyer {len(payload)} séance(s) à Intervals.icu ?"):
                return

            status, _ = post_events_to_intervals(self.intervals_key.get().strip(), payload)
            for idx in indices:
                src = self.sources[idx]
                if src["source_type"] == "notion":
                    if not self.notion_token.get().strip():
                        raise ValueError("Token Notion manquant pour mettre les statuts à Sync.")
                    update_notion_status(self.notion_token.get().strip(), src["page"]["id"], STATUS_SYNC)

            messagebox.showinfo("Terminé", f"{len(payload)} séance(s) envoyée(s). HTTP {status}")
            self.log(f"{len(payload)} séance(s) synchronisée(s)")
            self.load_notion()
        except Exception as exc:
            messagebox.showerror("Erreur d'envoi", str(exc))

    def add_manual(self):
        self.open_manual_editor()

    def open_manual_editor(self, index=None):
        edit = index is not None
        src = self.sources[index] if edit else None

        win = tk.Toplevel(self)
        win.title("Modifier une séance" if edit else "Ajouter une séance")
        win.geometry("720x680")
        win.minsize(640, 560)
        win.transient(self)
        win.grab_set()

        outer = ttk.Frame(win, style="White.TFrame")
        outer.pack(fill="both", expand=True, padx=18, pady=18)

        head = ttk.Frame(outer, style="Black.TFrame")
        head.pack(fill="x")
        ttk.Label(
            head,
            text="MODIFIER LA SÉANCE" if edit else "AJOUTER UNE SÉANCE MANUELLE",
            style="CardTitle.TLabel"
        ).pack(anchor="w", padx=14, pady=10)

        form = ttk.Frame(outer, style="White.TFrame")
        form.pack(fill="both", expand=True, padx=16, pady=(16, 8))

        dv = tk.StringVar(value=src["date"] if edit else "")
        sv = tk.StringVar(value=src["sport"] if edit else "Course")
        nv = tk.StringVar(value=src["name"] if edit else "")

        ttk.Label(form, text="Date (YYYY-MM-DD)", style="Card.TLabel").pack(anchor="w")
        ttk.Entry(form, textvariable=dv).pack(fill="x", pady=(4, 10))

        ttk.Label(form, text="Sport", style="Card.TLabel").pack(anchor="w")
        ttk.Combobox(
            form,
            textvariable=sv,
            values=["Course", "Vélo", "Home trainer"],
            state="readonly"
        ).pack(fill="x", pady=(4, 10))

        ttk.Label(form, text="Nom de la séance", style="Card.TLabel").pack(anchor="w")
        ttk.Entry(form, textvariable=nv).pack(fill="x", pady=(4, 10))

        ttk.Label(form, text="Contenu", style="Card.TLabel").pack(anchor="w")
        body = tk.Text(
            form,
            wrap="word",
            font=("Segoe UI", 10),
            bg="#FAFAFA",
            relief="flat",
            padx=10,
            pady=10,
            height=14
        )
        body.pack(fill="both", expand=True, pady=(4, 8))
        if edit:
            body.insert("1.0", src["details"])

        actions = ttk.Frame(outer, style="White.TFrame")
        actions.pack(fill="x", padx=16, pady=(0, 16))

        def save():
            d = dv.get().strip()
            sp = sv.get().strip()
            name = nv.get().strip()
            details = body.get("1.0", "end").strip()

            if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", d):
                messagebox.showerror("Erreur", "Date attendue : YYYY-MM-DD", parent=win)
                return
            if not name or not details:
                messagebox.showerror("Erreur", "Nom et contenu obligatoires.", parent=win)
                return

            if edit:
                src.update({
                    "date": d,
                    "sport": sp,
                    "name": name,
                    "details": details,
                    "edited_details": details
                })
                target = index
            else:
                self.sources.append({
                    "source_type": "manual",
                    "page": None,
                    "date": d,
                    "sport": sp,
                    "name": name,
                    "session_id": f"manual-{d}-{len(self.sources)+1}",
                    "details": details
                })
                target = len(self.sources) - 1

            self.refresh_tree()
            iid = str(target)
            self.tree.selection_set(iid)
            self.tree.focus(iid)
            self.tree.see(iid)
            self.select_source()
            win.destroy()
            self.log("Séance manuelle modifiée" if edit else "Séance manuelle ajoutée")

        def delete():
            if not edit:
                return
            if not messagebox.askyesno("Supprimer", f"Supprimer « {src['name']} » ?", parent=win):
                return
            self.sources.pop(index)
            self.checked_ids = {
                i if i < index else i - 1
                for i in self.checked_ids
                if i != index
            }
            self.current_source = None
            self.refresh_tree()
            win.destroy()
            self.log("Séance manuelle supprimée")

        ttk.Button(actions, text="ANNULER", style="White.TButton", command=win.destroy).pack(side="right")
        ttk.Button(
            actions,
            text="ENREGISTRER" if edit else "VALIDER ET AJOUTER",
            style="Orange.TButton",
            command=save
        ).pack(side="right", padx=(0, 10))
        if edit:
            ttk.Button(actions, text="SUPPRIMER", style="Black.TButton", command=delete).pack(side="left")

        win.bind("<Control-Return>", lambda event: save())
        win.bind("<Escape>", lambda event: win.destroy())

    def on_double_click(self, event):
        row = self.tree.identify_row(event.y)
        if row and self.sources[int(row)]["source_type"] == "manual":
            self.open_manual_editor(int(row))

    def show_context_menu(self, event):
        row = self.tree.identify_row(event.y)
        if row:
            self.tree.selection_set(row)
            self.tree.focus(row)
            self.select_source()
            self.context_menu.tk_popup(event.x_root, event.y_root)

    def delete_selected_source(self):
        sel = self.tree.selection()
        if not sel:
            return
        idx = int(sel[0])
        src = self.sources[idx]
        if messagebox.askyesno("Supprimer", f"Retirer « {src['name']} » de la liste ?"):
            self.sources.pop(idx)
            self.checked_ids = {i if i < idx else i - 1 for i in self.checked_ids if i != idx}
            self.refresh_tree()

    def open_settings(self):
        win = tk.Toplevel(self)
        win.title("Réglages")
        win.geometry("820x650")
        win.transient(self)
        win.grab_set()

        outer = ttk.Frame(win, style="White.TFrame")
        outer.pack(fill="both", expand=True, padx=18, pady=18)
        head = ttk.Frame(outer, style="Black.TFrame")
        head.pack(fill="x")
        ttk.Label(head, text="RÉGLAGES", style="CardTitle.TLabel").pack(anchor="w", padx=14, pady=10)

        notebook = ttk.Notebook(outer)
        notebook.pack(fill="both", expand=True, padx=14, pady=14)
        profile_tab = ttk.Frame(notebook, style="White.TFrame")
        syntax_tab = ttk.Frame(notebook, style="White.TFrame")
        tools_tab = ttk.Frame(notebook, style="White.TFrame")
        notebook.add(profile_tab, text="Zones personnelles")
        notebook.add(syntax_tab, text="Syntaxe Intervals")
        notebook.add(tools_tab, text="Connexion & diagnostic")

        rows = [
            ("Cyclisme — FTP", "ftp", "power"),
            ("Cyclisme — Puissance IM", "im_power", "power"),
            ("Running — Allure EF", "ef_pace", "pace"),
            ("Running — Allure marathon", "marathon_pace", "pace"),
            ("Running — Allure seuil", "threshold_pace", "pace"),
        ]
        vars_map = {}
        for r, (label, key, kind) in enumerate(rows):
            ttk.Label(profile_tab, text=label, style="Card.TLabel").grid(row=r, column=0, sticky="w", padx=12, pady=12)
            value = tk.StringVar(value=str(self.profile[key]))
            enabled = tk.BooleanVar(value=bool(self.profile.get(f"{key}_pct_enabled", True)))
            pct = tk.StringVar(value=str(self.profile.get(f"{key}_pct", 0)))
            preview = tk.StringVar()
            vars_map[key] = (value, enabled, pct, preview, kind)

            ttk.Entry(profile_tab, textvariable=value, width=12).grid(row=r, column=1, padx=6)
            ttk.Checkbutton(profile_tab, text="Borne ±", variable=enabled).grid(row=r, column=2, padx=6)
            ttk.Entry(profile_tab, textvariable=pct, width=7).grid(row=r, column=3, padx=6)
            ttk.Label(profile_tab, text="%", style="Card.TLabel").grid(row=r, column=4)
            ttk.Label(profile_tab, textvariable=preview, style="Card.TLabel").grid(row=r, column=5, sticky="w", padx=12)

            def update_preview(*_, k=key):
                v, en, pc, pr, kd = vars_map[k]
                try:
                    if not en.get():
                        pr.set(f"Cible exacte : {v.get()}")
                    else:
                        lo, hi = target_bounds(v.get(), float(pc.get()), kd)
                        suffix = " W" if kd == "power" else " /km"
                        pr.set(f"{lo} – {hi}{suffix}")
                except Exception:
                    pr.set("Valeur invalide")

            for var in (value, enabled, pct):
                var.trace_add("write", update_preview)
            update_preview()

        actions = ttk.Frame(profile_tab, style="White.TFrame")
        actions.grid(row=len(rows), column=0, columnspan=6, sticky="e", padx=12, pady=18)

        def save_profile():
            for key, (value, enabled, pct, _, kind) in vars_map.items():
                self.profile[key] = float(value.get()) if kind == "power" else normalize_pace(value.get())
                self.profile[f"{key}_pct_enabled"] = bool(enabled.get())
                self.profile[f"{key}_pct"] = float(pct.get())
            save_v6_config(self.database_id.get().strip(), self.profile)
            win.destroy()
            self.log("Réglages enregistrés")

        ttk.Button(actions, text="ENREGISTRER", style="Orange.TButton", command=save_profile).pack()

        syntax_help = """AIDE-MÉMOIRE — WORKOUT BUILDER INTERVALS.ICU

FORMAT GÉNÉRAL
- durée ou distance [cible] [cadence]
Exemples :
- 5m30s 60% 90rpm
- 1km 70% HR
- 500mtr 5:00/km Pace

DURÉE
1h
10m
30s
1h2m30s
5m30s
Formes courtes : 5', 30", 1'30"

DISTANCE
2km
500mtr
1mi
Important : m signifie minutes. Pour les mètres, utiliser mtr.

PUISSANCE
75%
95-105%
220w
200-240w
Z2
Z3-Z4
CZ1
CZ2-CZ3
60% MMP 5m

FRÉQUENCE CARDIAQUE
70% HR
75-80% HR
95% LTHR
90-95% LTHR
Z2 HR
Z2-Z3 HR

ALLURE
60% Pace
78-82% Pace
Z2 Pace
Z2-Z3 Pace
5:00 Pace
5:00/km Pace
3:00/100m-4:00/100m Pace
Sans unité, l’unité par défaut du sport est utilisée.

CADENCE VÉLO
- 10m 75% 90rpm
- 12m 85% 90-100rpm

RAMPES ET MODE LIBRE
- 10m ramp 50%-75%
- 15m ramp 60%-90% 85rpm
- 10m ramp 60-80% Pace
- 20m freeride

RÉPÉTITIONS
Main Set 4x
- 2m 95%
- 2m 55%

ou

5x
- 30s 120%
- 30s 50%

Bonnes pratiques :
- laisser une ligne vide avant et après un bloc répété ;
- ne pas imbriquer de répétitions.

CONSIGNES AFFICHÉES
Le texte avant la première durée devient une consigne :
- Warmup 10m 60%
- Recovery 3m 50%

PROMPTS CHRONOMÉTRÉS
- texte initial 33^texte à 33 secondes <!> 10m ramp 25-75%
Le nombre avant ^ est exprimé en secondes.
Le séparateur <!> est obligatoire.

MISE EN FORME
# Titre
**gras**
*italique*
[un lien](https://example.com)
---
La mise en forme organise le texte mais ne crée pas d’étapes.

Source adaptée du guide « Workout Builder Syntax Quick Guide »
du forum Intervals.icu.
"""

        syntax_container = ttk.Frame(syntax_tab, style="White.TFrame")
        syntax_container.pack(fill="both", expand=True, padx=12, pady=12)

        syntax_scroll = ttk.Scrollbar(syntax_container, orient="vertical")
        syntax_scroll.pack(side="right", fill="y")

        syntax_text = tk.Text(
            syntax_container,
            wrap="word",
            font=("Consolas", 10),
            bg="#FAFAFA",
            fg="#111827",
            relief="flat",
            padx=14,
            pady=14,
            yscrollcommand=syntax_scroll.set
        )
        syntax_text.pack(side="left", fill="both", expand=True)
        syntax_scroll.config(command=syntax_text.yview)
        syntax_text.insert("1.0", syntax_help)
        syntax_text.configure(state="disabled")

        ttk.Label(tools_tab, text=f"Version : {APP_VERSION}", style="Card.TLabel").pack(anchor="w", padx=16, pady=(18, 8))

        def test_notion():
            try:
                pages = query_notion_pages(self.notion_token.get().strip(), self.database_id.get().strip())
                messagebox.showinfo("Notion", f"Connexion réussie. {len(pages)} séance(s) To do trouvée(s).", parent=win)
            except Exception as exc:
                messagebox.showerror("Notion", str(exc), parent=win)

        def test_intervals():
            try:
                url = "https://intervals.icu/api/v1/athlete/0"
                _, data = http_json("GET", url, headers=intervals_headers(self.intervals_key.get().strip()))
                messagebox.showinfo("Intervals.icu", "Connexion réussie.", parent=win)
            except Exception as exc:
                messagebox.showerror("Intervals.icu", str(exc), parent=win)

        def export_log():
            out = Path.home() / "workout_sync_v6_log.txt"
            out.write_text("\n".join(self.logs), encoding="utf-8")
            messagebox.showinfo("Journal", f"Journal exporté :\n{out}", parent=win)

        ttk.Button(
            tools_tab,
            text="ENREGISTRER LES IDENTIFIANTS",
            style="Orange.TButton",
            command=self.save_credentials_now
        ).pack(anchor="w", padx=16, pady=(8, 4))

        ttk.Button(
            tools_tab,
            text="EFFACER LES IDENTIFIANTS",
            style="White.TButton",
            command=self.clear_saved_credentials
        ).pack(anchor="w", padx=16, pady=(4, 16))

        ttk.Button(tools_tab, text="TESTER NOTION", style="Black.TButton", command=test_notion).pack(anchor="w", padx=16, pady=8)
        ttk.Button(tools_tab, text="TESTER INTERVALS.ICU", style="Black.TButton", command=test_intervals).pack(anchor="w", padx=16, pady=8)
        ttk.Button(tools_tab, text="EXPORTER LE JOURNAL", style="White.TButton", command=export_log).pack(anchor="w", padx=16, pady=8)

if __name__ == "__main__":
    App().mainloop()
