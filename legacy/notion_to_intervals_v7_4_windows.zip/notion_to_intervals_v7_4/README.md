# Workout Sync V7

## Refactoring du parseur

Le parseur est maintenant séparé en règles dédiées et ordonnées.

### Course
1. lignes composées ;
2. répétitions temps + allure ;
3. répétitions distance + allure ;
4. répétitions simples ;
5. durées variables + allure ;
6. durées variables seules ;
7. EF / AS42 / marathon / seuil ;
8. zones Z1–Z7, Tempo et Sweet Spot ;
9. bornes d’allure ;
10. distance ou durée avec allure ;
11. durée ou distance seule.

### Vélo
1. lignes composées ;
2. répétitions + puissance ;
3. répétitions simples ;
4. durées variables + puissance ;
5. durées variables seules ;
6. puissance Ironman ;
7. zones ;
8. bornes de puissance ;
9. puissance explicite ;
10. cadence ;
11. durée seule.

## Règles transverses

- Natation exclue.
- Récupération sur ligne séparée rattachée à la répétition précédente.
- Récupération en distance prise en charge.
- Récupération complète = même durée que l’intervalle.
- Mètres convertis en kilomètres pour la course.
- Ponctuation et unités écrites normalisées.
- Contrôle de cohérence des répétitions.
- Syntaxe Python et cas principaux testés automatiquement.


## V7.1 — récupération automatique des répétitions courtes

- Effort répété inférieur à 1 minute sans récupération indiquée :
  - récupération ajoutée automatiquement ;
  - durée de récupération égale à la durée de l’effort.
- Exemple :
  ```text
  3 x 10" relâchées
  →
  3x
  - 10s
  - 10s
  ```
- À partir de 1 minute :
  - aucune récupération inventée ;
  - avertissement orange.
- Répétitions en distance :
  - aucune récupération inventée ;
  - avertissement orange.


## V7.2
- Boutons de la fenêtre d’ajout manuel restaurés et fixés en bas.
- Onglet `Syntaxe Intervals` ajouté dans `Réglages`.
- Aide-mémoire adapté du guide du forum Intervals.icu.


## V7.3 — répétitions avec récupération inline

L’ordre de détection est désormais strict :

1. distance + allure + récupération ;
2. temps + allure + récupération ;
3. distance + récupération ;
4. temps + récupération ;
5. répétitions sans récupération.

Exemple :

```text
3 x 10' à 4'05-4'10/km Récupération 3' facile
→
3x
- 10m 4:05-4:10 Pace
- 3m
```


## V7.4 — identifiants mémorisés

Les identifiants sont enregistrés en clair dans :

```text
%APPDATA%\WorkoutSync\credentials.json
```

Fonctionnement :

- chargement automatique au démarrage ;
- sauvegarde automatique à la fermeture ;
- bouton `Enregistrer les identifiants` dans Réglages ;
- bouton `Effacer les identifiants` ;
- champs concernés :
  - token Notion ;
  - clé API Intervals.icu ;
  - ID de la base Notion.
